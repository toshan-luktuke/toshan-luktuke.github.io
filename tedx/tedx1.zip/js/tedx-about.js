$("#TED").hover(function () {
    $("#li1").css("background-color", "white");
}, function () {
    $("#li1").css("background-color", "");
});

$("#TEDx").hover(function () {
    $("#li2").css("background-color", "white");
}, function () {
    $("#li2").css("background-color", "");
});

$("#TEDxS").hover(function () {
    $("#li3").css("background-color", "white");
}, function () {
    $("#li3").css("background-color", "");
});